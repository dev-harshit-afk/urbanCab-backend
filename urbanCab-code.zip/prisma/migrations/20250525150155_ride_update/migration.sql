-- AlterTable
ALTER TABLE "Ride" ADD COLUMN     "vehicleType" "VehicleType" NOT NULL DEFAULT 'auto';
